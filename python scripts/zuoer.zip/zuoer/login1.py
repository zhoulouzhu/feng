from logom import id,xpath,window_size,swip_up,tap

from  time import sleep
#driver=driver()
from data  import  clear
clear()
sleep(4)
def login1(username,password):
    s=window_size()


    sleep(5)


    try:

        a = xpath("//android.widget.FrameLayout[@index='0']")
    except Exception as rst:
        rst = 0
    else:
        rst = 1
        id("cn.sanfast.zhuoer.student:id/dialog_btn_cancel").click()

    try:
        b=xpath("//android.widget.FrameLayout[@index='0']")


    except Exception as  ret:
        rst=0
    else:
        rst= 1
        id("android:id/button1").click()
        id("android:id/button1").click()
        id("android:id/button1").click()
    swip_up()
    swip_up()
    swip_up()
    tap()
    id("cn.sanfast.zhuoer.student:id/main_shopping").click()
    id("cn.sanfast.zhuoer.student:id/main_share").click()
    id("cn.sanfast.zhuoer.student:id/et_phone").click()
    id("cn.sanfast.zhuoer.student:id/et_phone").send_keys(username)
    id("cn.sanfast.zhuoer.student:id/et_password").send_keys(password)
    id("cn.sanfast.zhuoer.student:id/btn_login").click()
    return login1(username,password)
login1(13052821327,123456)

