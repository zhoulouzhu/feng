#coding=utf-8

from appium import webdriver
from appium.webdriver.mobilecommand import MobileCommand
from time import  sleep

def driver():
    desired_caps = {}
    desired_caps['platformName'] = 'Android'
    desired_caps['platformVersion'] = '7.0'
    desired_caps['deviceName'] = '8e649992'
    desired_caps['appPackage'] = 'cn.sanfast.zhuoer.student'  #被测App的包名
    desired_caps['appActivity'] = 'cn.sanfast.zhuoer.student.activity.splash.SplashActivity' #启动时的Activity
    desired_caps['unicodeKeyboard'] = True
    desired_caps['resetKeyboard'] = True
    desired_caps['newCommandTimeout'] = 7200
    driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)


    return driver




