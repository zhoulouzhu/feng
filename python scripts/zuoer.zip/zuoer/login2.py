from zuoer.login1 import login1
from  logom import  id,xpath,id_val
from time import sleep
from data import clear

login1(13052821327,123456)
print("test2")
login1( "","123")
'''sleep(120)
try:

    id("cn.sanfast.zhuoer.student:id/main_shopping").click()
except:
    print("ttt")
try:

    a = id("cn.sanfast.zhuoer.student:id/main_shopping")
except Exception as rst:
   rst = 0
else:
    rst = 1
    xpath("//android.view.View[@content-desc=' 58 0 ']").click()'''





