from logom import id ,xpath,window_size
#logom("13058281327","123456")

#str="13052821327-123456"
#print(str.split('-'))
s=window_size()
print(s['width'])
print(s["height"])



try:

    a = xpath("//android.widget.FrameLayout[@index='0']")
except Exception as rst:
    rst = 0
else:
    rst = 1
    id("cn.sanfast.zhuoer.student:id/dialog_btn_cancel").click()
