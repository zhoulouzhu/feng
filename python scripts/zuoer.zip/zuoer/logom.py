from ddr import driver
from time import sleep
from appium import webdriver

driver=driver()

def id(id):
    sleep(3)
    return  driver.find_element_by_id(id)

def xpath(xpath):

    return driver.find_element_by_xpath(xpath)
def window_size():
    return  driver.get_window_size()
def  id_val(id,value):
    sleep(4)
    return  driver.find_element_by_id(id).send_keys(value)
def swip_up():
    s=window_size()
    driver.swipe(s['width'] * 0.8, s['height'] * 0.6, s['width'] * 0.01, s['height'] * 0.6, 500)
def tap():
    driver.tap([(593, 1555)], 500)


def zimu_to_shuzi(str):
    switch={
        'a': 29,
        'b': 30,
        'c': 31,
        'd': 32,
        'e': 33,
        'f': 34,
        'g': 35,
        'h': 36,
        'i': 37,
        'j': 38,
        'k': 39,
        'l': 40,
        'm': 41,
        'n': 42,
        'o': 43,
        'p': 44,
        'q': 45,
        'r': 46,
        's': 47,
        't': 48,
        'u': 49,
        'v': 50,
        'w': 51,
        'x': 52,
        'y': 53,
        'z': 54
    }
    return switch.get(str)
def key_input(str):
    for i in  str:
        print(i)
        driver.keyevent(zimu_to_shuzi(i))
